
// Luis Felipe 10420572 
// Marcos Minhano 10428577
// Matheus Fernandes 10420439

public class Main {
  public static void main(String[] args) {
    ProdutoRepo produtoRepo = new ProdutoRepo();
    produtoRepo.buscaProduto();
  }
}
public class Contador {
    int n = 0;

    void zerar() {
        this.n = 0;
    }

    void incrementar() {
        this.n += 1;
    }

    int getValor() {
        return this.n;
    }
}

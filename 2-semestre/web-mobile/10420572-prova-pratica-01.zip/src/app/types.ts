export interface Product {
    name: string;
    image: string;
    price: number;
    promotion: boolean;
}
